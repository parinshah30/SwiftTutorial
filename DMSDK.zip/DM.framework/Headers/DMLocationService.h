//
//  DMLocationService.h
//  ConnectIQ
//
//  Created by Parin Shah on 01/01/17.
//  Copyright (c) 2017 ConnectIQ. All rights reserved.
//

#import <CoreLocation/CoreLocation.h>

@interface DMLocationService : NSObject <CLLocationManagerDelegate>

@property (strong, nonatomic) CLLocationManager *locationManager;
@property (strong, nonatomic) CLLocation *lastLocation;
@property (nonatomic, assign) BOOL locationInProcess;
@property (strong, nonatomic) CLLocation * currentLocation;

+(DMLocationService *) sharedInstance;
- (BOOL)activateWithAppKey:(NSString *)appKey;
- (BOOL)setDriverMilesUserWithId:(NSString *)userId firstName:(NSString *)firstName lastName:(NSString *)lastName email:(NSString *)email age:(NSString *)age gender:(NSString *)gender dob:(NSString *)dob;
- (BOOL)isValidDriverMilesSession;
- (BOOL)activateLocationService;
- (void)deactivateLocationService;
- (BOOL)removeDriverMiles;

@end
