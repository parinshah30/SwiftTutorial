//
//  DriverMiles.h
//  DriverMiles
//
//  Created by Parin Shah on 12/3/16.
//  Copyright © 2016 Parin Shah. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DriverMiles.
FOUNDATION_EXPORT double DriverMilesVersionNumber;

//! Project version string for DriverMiles.
FOUNDATION_EXPORT const unsigned char DriverMilesVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DriverMiles/PublicHeader.h>

#import <DM/DMLocationService.h>
